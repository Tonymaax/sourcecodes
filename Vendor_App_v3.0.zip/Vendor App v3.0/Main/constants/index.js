import argonTheme from './Theme';
import articles from './articles';
import Images from './Images';
import tabs from './tabs';
import Language from './Language';

export {
  articles, 
  argonTheme,
  Images,
  tabs,
  Language
};